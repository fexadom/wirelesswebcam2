var querystring = require("querystring"),
	fs = require("fs");
	util = require('util');
	processor = require("./imageProcessor");

function start(response) {
	console.log("Request handler 'start' was called.");
	var body = '<html>'+
	'<head>'+
	'<meta http-equiv="Content-Type" content="text/html; '+
	'charset=UTF-8" />'+
	'</head>'+
	'<body>'+
	'<form action="/upload" enctype="multipart/form-data" method="post">'+
	'<input type="file" name="upload">'+
	'<input type="submit" value="Upload file" />'+
	'</form>'+
	'</body>'+
	'</html>';
	response.writeHead(200, {"Content-Type": "text/html"});
	response.write(body);
	response.end();
}

function uploadImage(response, request) {
	console.log("Request handler 'uploadImage' was called.");
	
	var queryData = new Buffer('');
	var counter = 0;
	var lengthAcc = 0;
	
	if(request.method == 'POST') {
		request.on('data', function(data) {
			
			queryData = Buffer.concat([queryData,data]);
			
			if(queryData.length > 1e6) {
                queryData = "";
                response.writeHead(413, {'Content-Type': 'text/plain'}).end();
                request.connection.destroy();
            }
		});
		
		request.on('end', function() {
			response.writeHead(200, {'Content-Type': 'text/plain'});
			response.end();
			processor.processImage(queryData);
		});
	}
}

function show(response) {
	console.log("Request handler 'show' was called.");
	var body = '<html>'+
	'<head>'+
	'<style>'+
	'html,body{'+
	'    margin:0;'+
	'	height:100%;'+
	'	overflow:hidden;'+
	'}'+
	'img{'+
	'	min-height:80%;'+
	'	min-width:80%;'+
	'	height:auto;'+
	'	width:auto;'+
	'	position:absolute;'+
	'	top:-50%; bottom:-50%;'+
	'	left:-50%; right:-50%;'+
	'	margin:auto;'+
	'}'+
	'</style>'+
	'</head>'+
	'<body>'+
	'<img src="http://200.126.23.246:8080/getImage" alt="">'+
	'</body>'+
	'</html>';
	response.writeHead(200, {"Content-Type": "text/html"});
	response.write(body);
	response.end();
}

function getImage(response) {
	console.log("Request handler 'show' was called.");
	response.setHeader("Cache-Control", "no-cache, no-store, must-revalidate"); // HTTP 1.1.
	response.setHeader("Pragma", "no-cache"); // HTTP 1.0.
	response.writeHead(200, {"Content-Type": "image/png"});
	fs.createReadStream(__dirname+"/image.png").pipe(response);
}

function showqr(response) {
	console.log("Request handler 'showqr' was called.");
	response.writeHead(200, {"Content-Type": "image/jpeg"});
	fs.createReadStream(__dirname+"/qrcode.jpg").pipe(response);
}

exports.start = start;
exports.show = show;
exports.showqr= showqr;
exports.uploadImage = uploadImage;
exports.getImage = getImage;
