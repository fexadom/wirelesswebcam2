require('buffer')

var bitmapFile = new Buffer(6);

console.log("hola1");

bitmapFile.writeUInt32LE(5454,0,2);
console.log("hola2");
