var fs = require('fs');
var Png = require('png').Png;

/* function processImage(data) {
	var width = 320;
	var height = 240;
	var bitmapSize = width*height*3+54;
	var bitmapFile = new Buffer(bitmapSize);
	
	bitmapFile.writeUInt32LE(19778,0,2);
	bitmapFile.writeUInt32LE(bitmapSize,2,4);
	bitmapFile.writeUInt32LE(54,10,4);
	bitmapFile.writeUInt32LE(40,14,4);
	bitmapFile.writeUInt32LE(width,18,4);
	bitmapFile.writeUInt32LE(height,22,4);
	bitmapFile.writeUInt32LE(1,26,2);
	bitmapFile.writeUInt32LE(24,28,2);
	
	for (i = 0, j = 54; i < width * height * 4; i += 4, j += 3)
	{
		bitmapFile[j + 0] = data[i + 2];
		bitmapFile[j + 1] = data[i + 1];
		bitmapFile[j + 2] = data[i + 0];
	}
	
	writeToFile(bitmapFile,'myBitmapFile.bmp');
} */

function processImage(data) {
	var png = new Png(data, 320, 240,'rgba');
	
	png.encode(function(png_image) {
		writeToFile(png_image,__dirname+'/image.png');
	});
}

function writeToFile(buffer,fileName)
{
	var wstream = fs.createWriteStream(fileName);
	wstream.write(buffer);
	wstream.end();
}

exports.processImage = processImage;
